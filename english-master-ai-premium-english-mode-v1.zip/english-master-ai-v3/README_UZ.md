# English Master AI — Premium Dark / English Lesson Mode

Telegram bot + Telegram Mini App. Node.js 18+, Express, Telegraf.

## Hozirgi imkoniyatlar
- Telegram Mini App interfeysi (Premium Dark: midnight navy, gold accents).
- Telegram Web App `initData` signature verification.
- Majburiy kanal obunasini tekshirish (`@vibes_topic`).
- AI chat endpoint (OpenAI-compatible Chat Completions API).
- AI tutor prompts configured for English-first teaching, adjusted to A0–C2; Uzbek help only when requested/needed.
- 20K+ vocabulary search and AI explanation.
- IELTS and Logistics curriculum data, lesson/week navigation, lesson completion and progress storage.
- Lesson video player support through optional `videoUrl` on a lesson. Lessons without a hosted video show a clear “Video lesson coming soon” placeholder.
- Anorbank manual payment request, receipt sent to admin in Telegram, approve/reject actions, course access expiry.
- Owner access via `OWNER_ID`.

## Local setup
1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and enter your own secret values.
4. Run `npm start`.

## Hosting environment variables
- `BOT_TOKEN` — fresh BotFather token; keep secret.
- `OWNER_ID=6239983618`
- `WEBAPP_URL` — deployed HTTPS URL.
- `OPENAI_API_KEY` — AI provider key; keep secret.
- `AI_MODEL=gpt-4o-mini`
- `AI_BASE_URL=https://api.openai.com/v1`
- `CARD_NUMBER` — Anorbank card used for manual transfers. Keep it in hosting secrets, not in source control.
- `DATA_DIR=/data` — persistent storage directory; attach a persistent volume on hosting.
- `REQUIRED_CHANNEL=@vibes_topic`
- `REQUIRED_CHANNEL_URL=https://t.me/vibes_topic`

Add the Telegram bot as an administrator to `@vibes_topic` so membership checks work. Set the bot's Telegram Web App URL to the deployed HTTPS URL.

## Important limitations before production
- This source package is not deployed. Configure hosting, secrets, Telegram bot, persistent storage, and AI provider first.
- Real video lessons are not included as video files. Add licensed/owned videos to a secure video host and set each lesson's `videoUrl` in `data/curriculum.json`.
- Voice speaking evaluation is not yet connected to a speech/audio recognition provider. Current AI chat accepts text; do not claim it has listened to audio.
- Anorbank transfers are manual: admin must verify the real bank transaction before approving. Never approve based only on a screenshot. Click/Payme are not integrated.
- Test payment approval, expiry, subscription gating, and data backups before accepting real payments.
- Use a persistent volume for `DATA_DIR`; ephemeral hosting storage can lose JSON data after redeploy/restart. For a larger production deployment, migrate JSON storage to PostgreSQL.
- Set rate limits, monitoring, backups, and HTTPS before public launch.

## Checks
Run `npm run check` to validate JavaScript syntax.
