require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const { Telegraf, Markup } = require('telegraf');
const app = express();
const PORT = Number(process.env.PORT || 3000);
const BOT_TOKEN = process.env.BOT_TOKEN || '';
const OWNER_ID = String(process.env.OWNER_ID || '');
const WEBAPP_URL = process.env.WEBAPP_URL || '';
const REQUIRED_CHANNEL = process.env.REQUIRED_CHANNEL || '@vibes_topic';
const REQUIRED_CHANNEL_URL = process.env.REQUIRED_CHANNEL_URL || 'https://t.me/vibes_topic';
const AI_KEY = process.env.OPENAI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || 'gpt-4o-mini';
const AI_BASE = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
// To‘lov kartasi: hostingda CARD_NUMBER bilan almashtirish mumkin.
const CARD_NUMBER = process.env.CARD_NUMBER || '';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'app-data.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
let db = { users: {}, payments: [], subscriptions: {}, progress: {} };
try { if (fs.existsSync(DB_FILE)) db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; } catch (e) { console.error('DB read:', e.message); }
function saveDb() { const tmp = DB_FILE + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(db, null, 2)); fs.renameSync(tmp, DB_FILE); }
const PRICES = { ielts_1: { course: 'ielts', title: 'IELTS — 1 oy', days: 30, amount: 199000 }, ielts_3: { course: 'ielts', title: 'IELTS — 3 oy', days: 90, amount: 519000 }, logistics_1: { course: 'logistics', title: 'Logistika — 1 oy', days: 30, amount: 999000 } };
const vocabulary = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'vocabulary.json'), 'utf8'));
const curriculum = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'curriculum.json'), 'utf8'));
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));

function verifyInitData(raw) {
  if (!raw || !BOT_TOKEN) return null;
  const p = new URLSearchParams(raw); const hash = p.get('hash'); if (!hash) return null; p.delete('hash');
  const check = [...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256','WebAppData').update(BOT_TOKEN).digest();
  const calc = crypto.createHmac('sha256',secret).update(check).digest('hex');
  const a=Buffer.from(calc,'hex'), b=Buffer.from(hash,'hex');
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return null;
  const authDate=Number(p.get('auth_date')||0); if(!authDate || Date.now()/1000-authDate>86400) return null;
  try { return JSON.parse(p.get('user')||'{}'); } catch { return null; }
}
function userFrom(req) {
  const u=verifyInitData(req.get('x-telegram-init-data')||'');
  if(u && u.id) return u;
  if(process.env.ALLOW_DEV_AUTH==='true') return {id:Number(req.get('x-dev-user-id')||'0'),first_name:'Demo'};
  return null;
}
let bot; // Telegram bot instance is initialized below.
async function isChannelMember(userId) {
  if (!bot || !REQUIRED_CHANNEL) return null;
  try {
    const member = await bot.telegram.getChatMember(REQUIRED_CHANNEL, userId);
    return ['creator', 'administrator', 'member'].includes(member.status) || (member.status === 'restricted' && member.is_member === true);
  } catch (error) {
    console.error('Kanal a’zoligini tekshirish:', error.description || error.message);
    return null;
  }
}
function subscriptionError(res, status=403) {
  return res.status(status).json({
    code: status === 403 ? 'SUBSCRIPTION_REQUIRED' : 'SUBSCRIPTION_CHECK_UNAVAILABLE',
    error: status === 403
      ? `Botdan foydalanish uchun avval ${REQUIRED_CHANNEL} kanaliga obuna bo‘ling: ${REQUIRED_CHANNEL_URL}. So‘ng Telegram botiga qaytib “Obunani tekshirish” tugmasini bosing.`
      : `Kanal a’zoligini tekshirib bo‘lmadi. Botni ${REQUIRED_CHANNEL} kanaliga administrator qilib qo‘shish kerak.`
  });
}
function requireUser(req,res,next){
  const u=userFrom(req);
  if(!u || !u.id) return res.status(401).json({error:'Telegram ichida oching yoki Mini App tasdiqlashini tekshiring.'});
  req.user=u;
  isChannelMember(u.id).then(member => {
    if (member === true) return next();
    if (member === false) return subscriptionError(res, 403);
    return subscriptionError(res, 503);
  }).catch(() => subscriptionError(res, 503));
}
app.get('/health',(_req,res)=>res.json({ok:true,service:'English Master AI',vocabularyCount:vocabulary.length,aiConfigured:Boolean(AI_KEY)}));
app.get('/api/status',requireUser,(req,res)=>{
 const id=String(req.user.id), owner=id===OWNER_ID, now=Date.now();
 const active=(db.subscriptions[id]||[]).filter(x=>x.expiresAt>now); db.subscriptions[id]=active;
 res.json({userId:req.user.id,isOwner:owner,aiConfigured:Boolean(AI_KEY),vocabularyCount:vocabulary.length,subscriptions:owner?['ielts','logistics']:active.map(x=>x.course),pendingPayments:db.payments.filter(x=>x.userId===id&&x.status==='pending').length});
});
app.get('/api/curriculum',requireUser,(req,res)=>{const id=String(req.user.id),owner=id===OWNER_ID,now=Date.now(),active=(db.subscriptions[id]||[]).filter(x=>x.expiresAt>now).map(x=>x.course);res.json({courses:curriculum.courses.map(c=>{const allowed=owner||active.includes(c.id);return allowed?c:{...c,lessons:[],weeklyPlan:[]};})});});
app.get('/api/payment-info',requireUser,(req,res)=>res.json({cardNumber:CARD_NUMBER,prices:PRICES,methods:['anorbank_manual']}));
app.post('/api/payment/request',requireUser,(req,res)=>{
 const plan=PRICES[String(req.body.plan||'')]; if(!plan)return res.status(400).json({error:'Kurs tarifi topilmadi.'});
 const payment={id:crypto.randomUUID(),userId:String(req.user.id),username:req.user.username||'',name:req.user.first_name||'',plan:Object.keys(PRICES).find(k=>PRICES[k]===plan),course:plan.course,title:plan.title,amount:plan.amount,days:plan.days,status:'awaiting_receipt',createdAt:Date.now()};
 db.payments.push(payment); db.users[String(req.user.id)]={id:req.user.id,name:req.user.first_name||'',username:req.user.username||'',updatedAt:Date.now()}; saveDb();
 res.json({paymentId:payment.id,title:plan.title,amount:plan.amount,cardNumber:CARD_NUMBER,instruction:'Kartaga pul o‘tkazing, so‘ng chekni Telegram botga rasm qilib yuboring.'});
});
app.get('/api/admin/payments',requireUser,(req,res)=>{if(String(req.user.id)!==OWNER_ID)return res.status(403).json({error:'Faqat admin.'});res.json({payments:db.payments.slice(-100).reverse()});});
app.post('/api/admin/payment/:id/:action',requireUser,(req,res)=>{
 if(String(req.user.id)!==OWNER_ID)return res.status(403).json({error:'Faqat admin.'});
 const p=db.payments.find(x=>x.id===req.params.id); if(!p||!['approve','reject'].includes(req.params.action))return res.status(404).json({error:'To‘lov topilmadi.'});
 if(p.status==='approved'||p.status==='rejected')return res.status(409).json({error:'To‘lov avval ko‘rib chiqilgan.'});
 p.status=req.params.action==='approve'?'approved':'rejected';p.reviewedAt=Date.now();
 if(p.status==='approved'){const list=db.subscriptions[p.userId]||[];const current=list.find(x=>x.course===p.course&&x.expiresAt>Date.now());const start=current?current.expiresAt:Date.now();list.push({course:p.course,startsAt:start,expiresAt:start+p.days*86400000,paymentId:p.id});db.subscriptions[p.userId]=list;}saveDb();
 if(bot){const msg=p.status==='approved'?`✅ To‘lov tasdiqlandi! ${p.title} kursiga kirish ochildi.`:'❌ To‘lov tasdiqlanmadi. Iltimos, admin bilan bog‘laning.';bot.telegram.sendMessage(p.userId,msg).catch(()=>{});}
 res.json({ok:true,status:p.status});
});
app.get('/api/progress',requireUser,(req,res)=>res.json({progress:db.progress[String(req.user.id)]||{}}));
app.post('/api/progress',requireUser,(req,res)=>{const id=String(req.user.id);db.progress[id]={...(db.progress[id]||{}),...(req.body.progress||{})};saveDb();res.json({ok:true});});
app.get('/api/vocab',requireUser,(req,res)=>{
  const q=String(req.query.q||'').trim().toLowerCase(); const limit=Math.min(100,Math.max(1,Number(req.query.limit)||30));
  if(q.length<1) return res.json({total:vocabulary.length,items:[]});
  const start=Math.max(0,Number(req.query.offset)||0);
  const found=[];
  // Prefix matches first, then substring matches.
  for(const x of vocabulary){ if(x.word.startsWith(q)) found.push(x); if(found.length>=limit+start) break; }
  if(found.length<limit+start){ for(const x of vocabulary){ if(!x.word.startsWith(q)&&x.word.includes(q)) found.push(x); if(found.length>=limit+start) break; } }
  res.json({total:vocabulary.length,items:found.slice(start,start+limit)});
});
app.post('/api/chat',requireUser,async(req,res)=>{
  if(!AI_KEY) return res.status(503).json({error:'AI hali ulanmagan. Hosting sozlamalariga OPENAI_API_KEY kiriting.'});
  const messages=Array.isArray(req.body.messages)?req.body.messages.slice(-16):[];
  const clean=messages.filter(m=>m && ['user','assistant'].includes(m.role) && typeof m.content==='string').map(m=>({role:m.role,content:m.content.slice(0,5000)}));
  if(!clean.length || clean[clean.length-1].role!=='user') return res.status(400).json({error:'Savolingizni yozing.'});
  const system=`You are English Master AI, a warm, highly capable English tutor and conversational AI partner. Speak primarily in English because the learner selected English-only lesson mode. Adapt your English to the learner’s CEFR level: for A0/A1 use very short, clear sentences, common words, repetition, examples, and check understanding one question at a time. Do not switch to Uzbek automatically. If the learner explicitly asks for Uzbek or is completely stuck, give a brief Uzbek clarification, then return to simple English practice. Answer broad general questions too, not only English questions; if a question is unrelated to English, answer helpfully and then gently offer to connect it to English practice only when appropriate. For English learning: diagnose level, correct errors kindly, show the corrected sentence, explain the reason in simple English, give 1-2 natural examples, and ask one useful follow-up question. Use Uzbek only when explicitly requested. Support CEFR A0-C2, IELTS all four skills, speaking simulations, vocabulary, pronunciation guidance, grammar, writing feedback and comprehensive logistics operations. For logistics, act as a practical operations mentor: explain supply chain, transport, warehouse, freight forwarding, dispatch, broker/carrier/shipper communication, load booking, rate negotiation, counteroffers, rate confirmations, tracking, documentation, customs concepts, and problem-solving. The user may describe any logistics problem freely in Uzbek or their preferred language, with typos, slang, or incomplete details; understand natural language without requiring commands, menus, or forms. In lessons, teach in English first; if the user asks a practical question in Uzbek, answer that question in Uzbek when helpful, then resume English practice. Restate the understood issue briefly, ask only one key clarifying question at a time, then give an actionable step-by-step plan. When useful, draft ready-to-send English messages or call scripts and provide Uzbek translations. Offer realistic role-play as broker, dispatcher, driver, shipper, warehouse, or customer; negotiate fictional practice rates only and label them as examples, never as live market prices. Help with rate calculations using user-provided figures, explain deadhead, all-in rate, detention, layover, TONU and accessorials, and remind the user to verify written terms before accepting a load. Do not invent live rates, load availability, shipment status, laws, customs rulings, or contract terms. Never claim to hear pronunciation unless audio was actually provided; text transcription can be assessed for grammar and naturalness. For IELTS, distinguish estimated feedback from an official band score. Avoid making up facts; state uncertainty. Keep replies readable and engaging. User's current message language may be Uzbek or English.`;
  try{
    const response=await fetch(`${AI_BASE}/chat/completions`,{method:'POST',headers:{'Authorization':`Bearer ${AI_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:AI_MODEL,messages:[{role:'system',content:system},...clean],temperature:0.7})});
    const data=await response.json(); if(!response.ok) return res.status(502).json({error:data.error?.message||'AI provayderida xatolik.'});
    res.json({reply:data.choices?.[0]?.message?.content||'Javob olinmadi.'});
  }catch(e){console.error('AI request:',e.message);res.status(502).json({error:'AI serveriga ulanib bo‘lmadi.'});}
});
app.post('/api/vocab-explain',requireUser,async(req,res)=>{
  if(!AI_KEY) return res.status(503).json({error:'So‘z tarjimasi uchun OPENAI_API_KEY kerak.'});
  const word=String(req.body.word||'').trim().slice(0,80); if(!word) return res.status(400).json({error:'So‘z topilmadi.'});
  try{const r=await fetch(`${AI_BASE}/chat/completions`,{method:'POST',headers:{'Authorization':`Bearer ${AI_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:AI_MODEL,temperature:0.2,messages:[{role:'system',content:'You are an English vocabulary coach. Reply primarily in simple English: definition, part of speech, pronunciation hint, one natural example, and a common collocation. Add a short Uzbek translation only as a small support line. Be concise.'},{role:'user',content:`Explain this English word: ${word}`} ]})});const d=await r.json();if(!r.ok)return res.status(502).json({error:d.error?.message||'AI xatosi'});res.json({explanation:d.choices?.[0]?.message?.content||''});}catch(e){res.status(502).json({error:'AI serveriga ulanib bo‘lmadi.'});}
});
if(BOT_TOKEN){
 bot=new Telegraf(BOT_TOKEN);
 const joinKeyboard = () => Markup.inlineKeyboard([
   [Markup.button.url('📢 Kanalga obuna bo‘lish', REQUIRED_CHANNEL_URL)],
   [Markup.button.callback('✅ Obunani tekshirish', 'check_subscription')]
 ]);
 const mainMenu = () => { const rows=[]; if(WEBAPP_URL.startsWith('https://')) rows.push([Markup.button.webApp('🚀 English Master AI ni ochish',WEBAPP_URL)]); rows.push([Markup.button.callback('📚 Kurs narxlari va to‘lov','course_payment')]); return Markup.inlineKeyboard(rows); };
 const requireChannelInBot = async ctx => {
   const member = await isChannelMember(ctx.from.id);
   if (member === true) return true;
   if (member === false) { await ctx.reply(`🔒 English Master AI’dan foydalanish uchun avval ${REQUIRED_CHANNEL} kanaliga obuna bo‘ling.\n\nObuna bo‘lgach, “Obunani tekshirish” tugmasini bosing.`, joinKeyboard()); return false; }
   await ctx.reply(`⚠️ Kanal obunasini tekshirib bo‘lmadi. Bot administratori botni ${REQUIRED_CHANNEL} kanaliga administrator qilib qo‘shishi kerak.`);
   return false;
 };
 bot.start(async ctx=>{ if(!await requireChannelInBot(ctx)) return; await ctx.reply('✨ English Master AI\n\nAI ustoz, 20 000+ lug‘at, IELTS va American Logistics kurslari. Boshlash uchun tugmani bosing.',mainMenu()); });
 bot.action('check_subscription',async ctx=>{
   await ctx.answerCbQuery();
   const member = await isChannelMember(ctx.from.id);
   if(member === true) return ctx.reply('✅ Obunangiz tasdiqlandi! Endi botdan foydalanishingiz mumkin.', mainMenu());
   if(member === false) return ctx.reply('❌ Hali kanalga obuna bo‘lmagansiz. Obuna bo‘lib, yana tekshiring.', joinKeyboard());
   return ctx.reply(`⚠️ Tekshiruv ishlamadi. Botni ${REQUIRED_CHANNEL} kanaliga administrator qilib qo‘shish kerak.`);
 });
 bot.action('course_payment',async ctx=>{await ctx.answerCbQuery();if(!await requireChannelInBot(ctx))return;await ctx.reply(`📚 ENGLISH MASTER AI — KURSLAR VA TO‘LOV\n\n🎓 IELTS kursi\n• 1 oy — 199 000 so‘m\n• 3 oy — 519 000 so‘m\n\n🚚 Umumiy logistika kursi\n• 1 oy — 999 000 so‘m\n\n💳 ANORBANK KARTA\n${CARD_NUMBER || 'Karta raqami hali hosting sozlamalariga kiritilmagan.'}\n\nTo‘lov izohida ism-familiyangizni yozing. To‘lovdan keyin chek yoki tranzaksiya skrinshotini shu botga yuboring. Admin tekshiradi va siz bilan bog‘lanadi.\n\n⚠️ Hozircha to‘lov qo‘lda tekshiriladi. Click/Payme avtomatik to‘lovi hali ulanmagan.`);});
 bot.on('photo',async ctx=>{
   if(!await requireChannelInBot(ctx)) return;
   const from=ctx.from, uid=String(from.id);
   const payment=[...db.payments].reverse().find(x=>x.userId===uid&&['awaiting_receipt','pending'].includes(x.status));
   if(!payment){await ctx.reply('Avval Mini App ichida kurs va tarifni tanlab, to‘lov so‘rovini yarating.');return;}
   payment.status='pending';payment.receiptFileId=ctx.message.photo[ctx.message.photo.length-1].file_id;payment.receiptAt=Date.now();saveDb();
   const who=`${from.first_name||''} ${from.last_name||''}`.trim();
   const caption=`🧾 TO‘LOV CHEKI\nKurs: ${payment.title}\nSumma: ${payment.amount.toLocaleString('uz-UZ')} so‘m\nFoydalanuvchi: ${who||'Noma’lum'}\nTelegram ID: ${from.id}\nUsername: ${from.username?'@'+from.username:'yo‘q'}\nPayment ID: ${payment.id}\n\nBank ilovasidan tushumni tekshiring.`;
   try{await bot.telegram.sendPhoto(OWNER_ID,ctx.message.photo[ctx.message.photo.length-1].file_id,{caption, ...Markup.inlineKeyboard([[Markup.button.callback('✅ Tasdiqlash','payok:'+payment.id)],[Markup.button.callback('❌ Rad etish','payno:'+payment.id)]])});}catch(e){console.error('Chekni adminga yuborish:',e.message);await ctx.reply('Chek qabul qilindi, lekin adminga yetkazishda xatolik yuz berdi.');return;}
   await ctx.reply('✅ Chekingiz adminga yuborildi. To‘lov bank ilovasida tekshirilgach, kurs avtomatik ochiladi.');
 });
 bot.action(/^payok:(.+)$/,async ctx=>{if(String(ctx.from.id)!==OWNER_ID)return ctx.answerCbQuery('Ruxsat yo‘q');const id=ctx.match[1],p=db.payments.find(x=>x.id===id);if(!p||p.status!=='pending')return ctx.answerCbQuery('To‘lov topilmadi yoki ko‘rib chiqilgan');p.status='approved';p.reviewedAt=Date.now();const list=db.subscriptions[p.userId]||[];const cur=list.find(x=>x.course===p.course&&x.expiresAt>Date.now());const start=cur?cur.expiresAt:Date.now();list.push({course:p.course,startsAt:start,expiresAt:start+p.days*86400000,paymentId:p.id});db.subscriptions[p.userId]=list;saveDb();await bot.telegram.sendMessage(p.userId,`✅ To‘lov tasdiqlandi! ${p.title} kursiga kirish ochildi.`);await ctx.answerCbQuery('Tasdiqlandi');await ctx.editMessageCaption((ctx.callbackQuery.message.caption||'')+'\n\n✅ ADMIN TASDIQLADI');});
 bot.action(/^payno:(.+)$/,async ctx=>{if(String(ctx.from.id)!==OWNER_ID)return ctx.answerCbQuery('Ruxsat yo‘q');const id=ctx.match[1],p=db.payments.find(x=>x.id===id);if(!p||p.status!=='pending')return ctx.answerCbQuery('To‘lov topilmadi yoki ko‘rib chiqilgan');p.status='rejected';p.reviewedAt=Date.now();saveDb();await bot.telegram.sendMessage(p.userId,'❌ To‘lov tasdiqlanmadi. Iltimos, chek va summa bo‘yicha admin bilan bog‘laning.');await ctx.answerCbQuery('Rad etildi');await ctx.editMessageCaption((ctx.callbackQuery.message.caption||'')+'\n\n❌ ADMIN RAD ETDI');});
 bot.on('text',async ctx=>{if(ctx.message.text.startsWith('/'))return;if(!await requireChannelInBot(ctx))return;await ctx.reply('AI bilan suhbatlashish uchun Mini App ichidagi “AI Ustoz” bo‘limini oching.');});
 bot.launch().then(()=>console.log('Telegram bot polling ishga tushdi.')).catch(e=>console.error('Bot launch:',e.message));
} else { console.warn('BOT_TOKEN yo‘q: web app ishlaydi, Telegram bot ishga tushmaydi.'); }
app.listen(PORT,'0.0.0.0',()=>console.log(`English Master AI ${PORT}-portda. Lug‘at: ${vocabulary.length}`));
process.once('SIGINT',()=>bot?.stop('SIGINT'));process.once('SIGTERM',()=>bot?.stop('SIGTERM'));
